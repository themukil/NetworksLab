#include <iostream>
#include <cstring>
#include <arpa/inet.h>
#include <unistd.h>

int main() {
    // Create a UDP socket
    int client_socket = socket(AF_INET, SOCK_DGRAM, 0);

    // Server address information
    sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = inet_addr("127.0.0.1");
    server_address.sin_port = htons(12345);

    char buffer[1024];

    while (true) {
        // Get user input
        std::cout << "Enter your message: ";
        std::cin.getline(buffer, sizeof(buffer));

        // Send the message to the server
        sendto(client_socket, buffer, strlen(buffer), 0, (struct sockaddr*)&server_address, sizeof(server_address));

        // Receive the response from the server
        ssize_t bytes_received = recvfrom(client_socket, buffer, sizeof(buffer), 0, nullptr, nullptr);
        buffer[bytes_received] = '\0';

        std::cout << "Received response: " << buffer << std::endl;
    }

    // Close the socket
    close(client_socket);

    return 0;
}
