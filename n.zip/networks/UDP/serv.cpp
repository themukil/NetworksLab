#include <iostream>
#include <cstring>
#include <arpa/inet.h>
#include <unistd.h>

int main() {
    // Create a UDP socket
    int server_socket = socket(AF_INET, SOCK_DGRAM, 0);

    // Server address information
    sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(12345);

    // Bind the socket
    bind(server_socket, (struct sockaddr*)&server_address, sizeof(server_address));

    std::cout << "Server listening on port 12345..." << std::endl;

    char buffer[1024];

    while (true) {
        // Receive data from the client
        sockaddr_in client_address;
        socklen_t client_address_len = sizeof(client_address);
        ssize_t bytes_received = recvfrom(server_socket, buffer, sizeof(buffer), 0, (struct sockaddr*)&client_address, &client_address_len);

        buffer[bytes_received] = '\0';

        std::cout << "Received message from " << inet_ntoa(client_address.sin_addr) << ":" << ntohs(client_address.sin_port) << ": " << buffer << std::endl;

        // Send a response back to the client
        std::cout << "Enter your response: ";
        std::cin.getline(buffer, sizeof(buffer));
        sendto(server_socket, buffer, strlen(buffer), 0, (struct sockaddr*)&client_address, client_address_len);
    }

    // Close the socket
    close(server_socket);

    return 0;
}
