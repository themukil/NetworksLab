#include <iostream>
#include <cstring>
#include <arpa/inet.h>
#include <unistd.h>

const int PORT = 12345;
const int BUFFER_SIZE = 1024;

int main() {
    // Create socket
    int clientSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (clientSocket == -1) {
        std::cerr << "Error creating socket\n";
        return -1;
    }

    // Server address
    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &serverAddr.sin_addr);

   while(1){ // Get the hostname from the user
    std::cout << "Enter the hostname to resolve: ";
    std::string hostname;
    std::cin >> hostname;

    // Send DNS request to the server
    sendto(clientSocket, hostname.c_str(), hostname.length(), 0, (struct sockaddr*)&serverAddr, sizeof(serverAddr));

    // Receive the response from the server
    char buffer[BUFFER_SIZE];
    ssize_t bytesReceived = recvfrom(clientSocket, buffer, BUFFER_SIZE, 0, nullptr, nullptr);
    if (bytesReceived == -1) {
        std::cerr << "Error receiving data\n";
        close(clientSocket);
        return -1;
    }

    buffer[bytesReceived] = '\0'; // Null-terminate the received data

    // Display the resolved IP address
    std::cout << "Resolved IP address: " << buffer << std::endl;
   }
    // Close the socket
    close(clientSocket);

    return 0;
}
