#include <iostream>
#include <cstring>
#include <map>
#include <arpa/inet.h>
#include <unistd.h>

const int PORT = 12345;
const int BUFFER_SIZE = 1024;

std::map<std::string, std::string> dnsMap = {
    {"www.example.com", "192.168.1.1"},
    {"mail.example.com", "192.168.1.2"},
    {"api.example.com", "192.168.1.3"},
    // Add more mappings as needed
};

int main() {
    // Create socket
    int serverSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (serverSocket == -1) {
        std::cerr << "Error creating socket\n";
        return -1;
    }

    // Bind the socket
    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == -1) {
        std::cerr << "Error binding socket\n";
        close(serverSocket);
        return -1;
    }

    std::cout << "DNS Server is running on port " << PORT << std::endl;

    // Server loop
    while (true) {
        char buffer[BUFFER_SIZE];
        sockaddr_in clientAddr;
        socklen_t clientLen = sizeof(clientAddr);

        // Receive DNS request from client
        ssize_t bytesReceived = recvfrom(serverSocket, buffer, BUFFER_SIZE, 0, (struct sockaddr*)&clientAddr, &clientLen);
        if (bytesReceived == -1) {
            std::cerr << "Error receiving data\n";
            continue;
        }

        buffer[bytesReceived] = '\0'; // Null-terminate the received data

        // Lookup IP address in the DNS mapping
        std::string hostname(buffer);
        std::string ipAddress = dnsMap[hostname];

        // Send the response back to the client
        sendto(serverSocket, ipAddress.c_str(), ipAddress.length(), 0, (struct sockaddr*)&clientAddr, sizeof(clientAddr));
    }

    // Close the socket
    close(serverSocket);

    return 0;
}
