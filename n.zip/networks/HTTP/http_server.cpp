#include <bits/stdc++.h>
#include <sstream>
#include <string>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>

using namespace std;

int main() {
    int ssock = socket(AF_INET, SOCK_STREAM, 0);
    sockaddr_in saddr;
    saddr.sin_family = AF_INET;
    saddr.sin_port = htons(3004);
    saddr.sin_addr.s_addr = INADDR_ANY;
    bind(ssock, (sockaddr*)&saddr, sizeof(saddr));
    listen(ssock, 5);
    char buff[300];
    while (1) {
        sockaddr_in cli;
    socklen_t ln = sizeof(cli);
        int csock = accept(ssock, (sockaddr*)&cli, &ln);
        recv(csock, buff, 300, 0);
        istringstream req(buff);
        string m, p, v;
        req >> m >> p >> v;

        if (m == "GET") {
            if (p == "/exit") {
                close(csock);
                break;
            }
            else if(p == "/"){
                ifstream file("index.html",ios::binary | ios::in);
                stringstream d;
                d << file.rdbuf();
                string con = d.str();
                string res = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n";
                res += "content-length : " + to_string(con.length())+"\r\n\r\n";
                res += con;
                cout<<res<<endl;
                send(csock, res.c_str(), res.size(), 0);
            }
            else if(p == "/about"){
                ifstream file("about.html",ios::binary | ios::in);
                stringstream d;
                d << file.rdbuf();
                string con = d.str();
                string res = "HTTP/1.1 200 OK\r\n";
                res += "content-type : text/html\r\n";
                res += "content-length : " + to_string(con.length()) + "\r\n";
                res += "\r\n"+con;
                send(csock,res.c_str(),res.length(),0);
            }
            else{
                ifstream file("ntfnd.html",ios::binary | ios::in);
                stringstream d;
                d << file.rdbuf();
                string con = d.str();
                string res = "HTTP/1.1 404 NOT FOUND\r\n";
                res += "content-type : text/html\r\n";
                res += "content-length : " + to_string(con.length()) + "\r\n";
                res += "\r\n"+con;
                send(csock,res.c_str(),res.length(),0);
            }
        }

        close(csock);
    }

    close(ssock);
 
    return 0;
}
