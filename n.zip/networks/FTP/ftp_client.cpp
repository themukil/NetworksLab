#include <bits/stdc++.h>
#include <cstring>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
using namespace std;

int main() {
    int clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    sockaddr_in serverAddress;
    string ip = "";
    cout<<"\nEnter the host [Enter for default] : ";
    getline(cin,ip);
    cout<<ip;
    if(ip == ""){
        ip = "127.0.0.1";
    }
    string port;
    cout<<"Port [Enter for default] : ";
    getline(cin,port);
    if(port == ""){
        port = "3009";
    }
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(stoi(port));
    serverAddress.sin_addr.s_addr = inet_addr(ip.c_str());

    if (connect(clientSocket, (struct sockaddr *) &serverAddress, sizeof(serverAddress)) == -1) {
        std::cerr << "Error connecting to the server" << std::endl;
        close(clientSocket);
        return -1;
    }
    while(1){
    std::cout << "\033[32mftp@"<<ip<<":"<<port<<"$ \033[0m" ;
    std::string userCommand;
    std::getline(std::cin, userCommand);
    if(userCommand == "clear"){
        std::cout << "\033[H\033[2J\033[3J" ;
        continue;
    }
    if(userCommand == "exit"){
        std::cout<<"bye";
        break;
    }
    char buff[300];
    bzero(buff,300);
    if (userCommand[0] == 'r') {
            int pos = 5;
            while (pos < userCommand.size() && userCommand[pos] != ' ') {
                pos++;
            }
            cout<<userCommand.substr(0,pos)<<endl;
            string fn = (pos == userCommand.size()) ? "recv" + userCommand.substr(5) : userCommand.substr(pos + 1);
            send(clientSocket, userCommand.substr(0,pos).c_str(), pos, 0);
            ssize_t bytesReceived;
            cout<<fn<<endl;
            FILE *f = fopen(fn.c_str(), "wb"); // Use "wb" for binary mode
            if (f == nullptr) {
                cerr << "Error opening file for writing" << endl;
                break;
            }

            while ((bytesReceived = recv(clientSocket, buff, sizeof(buff), 0)) > 0) {
                fwrite(buff, 1, bytesReceived, f);
                bzero(buff, 300);
            }

            fclose(f);
            cout << "COMPLETED... \n file saved as " << fn << endl;
        }
    else{
    	send(clientSocket, userCommand.c_str(), userCommand.length(), 0);
        ssize_t bytesReceived;
	    while ((bytesReceived = recv(clientSocket, buff, sizeof(buff), 0)) > 0) {
		std::cout.write(buff, bytesReceived);
		bzero(buff,300);
        }
    }
        clientSocket = socket(AF_INET, SOCK_STREAM, 0);
       connect(clientSocket, (struct sockaddr *) &serverAddress, sizeof(serverAddress));
    }
    close(clientSocket);
    return 0;
}
