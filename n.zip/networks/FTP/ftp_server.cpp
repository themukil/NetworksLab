#include <bits/stdc++.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <dirent.h>

using namespace std;

int main() {
    int serv_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (serv_sock == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }
    sockaddr_in sa;
    sa.sin_addr.s_addr = INADDR_ANY;
    sa.sin_port = htons(3009);
    sa.sin_family = AF_INET;
    if (bind(serv_sock, (sockaddr*)&sa, sizeof(sa)) == -1) {
        perror("Bind failed");
        close(serv_sock);
        exit(EXIT_FAILURE);
    }
    if (listen(serv_sock, 5) == -1) {
        perror("Listen failed");
        close(serv_sock);
        exit(EXIT_FAILURE);
    }
    while (true) {
        sockaddr_in cli;
        socklen_t len = sizeof(cli);
        int c = accept(serv_sock, (sockaddr*)&cli, &len);
        if (c == -1) {
            perror("Accept failed");
            close(serv_sock);
            exit(EXIT_FAILURE);
        }

        char buff[300];
        bzero(buff,300);
        ssize_t bytes_received = recv(c, buff, sizeof(buff), 0);
        if (bytes_received == -1) {
            perror("Receive failed");
            close(c);
            continue;
        }
        string s(buff);
        cout<<s;
        if (s[0] == 'l') {
            string path = ".";
            if(strlen(buff) != 4){
                path = s.substr(5);
            }
            DIR* dir;
            string resp;
            struct dirent* ent;
            if ((dir = opendir(path.c_str())) != NULL) {
                while ((ent = readdir(dir)) != NULL) {
                    resp += string(ent->d_name);
                    resp += "\n";
                }
                closedir(dir);
                cout << resp;
                send(c, resp.c_str(), resp.length(), 0);
            }
        }
	    else if (s[0] == 'r') {
            FILE* f = fopen(s.substr(5, strlen(buff) -1).c_str(), "rt");
            if (f == NULL) {
            perror("File not found");
            close(c);
            } else {
            ssize_t bytes_read;
            while ((bytes_read = fread(buff, 1, sizeof(buff), f)) > 0) {
                if (send(c, buff, bytes_read, 0) == -1) {
                    perror("Send failed");
                    fclose(f);
                    close(c);
                    break;  // exit the loop if there's an error in sending
                }
		}
            }
        fclose(f);
        }
        else if(s[0] == 'd'){
            if(remove(s.substr(4, strlen(buff) -1).c_str()) == 0){
                string d = "DELETE SUCCESSFUL\n";
                send(c,d.c_str(),d.size(),0);
            }
            else{
                string d = "DELETE ERROR\n";
                send(c,d.c_str(),d.size(),0);
            }

        }
        close(c);
	    }
    
    close(serv_sock);
    return 0;
	}
