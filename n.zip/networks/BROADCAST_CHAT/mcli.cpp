#include <iostream>
#include <unistd.h>
#include <arpa/inet.h>
#include <thread>
#include <mutex>

using namespace std;

int clientSocket;
mutex coutMutex;
void userInput() {
    while (true) {
        char message[300];
        cin.getline(message, sizeof(message));
        send(clientSocket, message, sizeof(message), 0);
    }
}

// Function to handle server messages and printing
void receiveMessages() {
    while (true) {
        char message[300];
        recv(clientSocket, message, sizeof(message), 0);
        lock_guard<mutex> lock(coutMutex);
        cout << message << endl;
    }
}

int main() {
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    sockaddr_in serverAddress;

    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(9000);
    inet_pton(AF_INET, "127.0.0.1", &serverAddress.sin_addr);

    if (connect(clientSocket, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) == 0) {
        cout << "Connected to the server." << endl;
        thread inputThread(userInput);
        thread receiveThread(receiveMessages);
        inputThread.join();
        receiveThread.join();
    } else {
        cout << "Failed to connect to the server." << endl;
    }

    close(clientSocket);

    return 0;
}