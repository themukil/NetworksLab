#include <bits/stdc++.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/socket.h>
#include <thread>
#include <vector>

using namespace std;

vector<int> clients;
void recv_msg(int csock) {
    char buff[300];
    int bytesReceived;

    while ((bytesReceived = recv(csock, buff, sizeof(buff), 0)) > 0) {
        for (int i : clients) {
            if (i == csock)
                continue;
            send(i, buff, bytesReceived, 0);
        }
    }
}

int main() {
    int ssock = socket(AF_INET, SOCK_STREAM, 0);
    sockaddr_in saddr;
    saddr.sin_addr.s_addr = INADDR_ANY;
    saddr.sin_family = AF_INET;
    saddr.sin_port = htons(9000);
    bind(ssock, (sockaddr*)&saddr, sizeof(saddr));
    listen(ssock, 10);

    while (true) {
        sockaddr_in cli;
        socklen_t ln = sizeof(cli);
        int c = accept(ssock, (sockaddr*)&cli, &ln);
        clients.push_back(c);
        thread(recv_msg, c).detach();
    }

    return 0;
}
