#include<bits/stdc++.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<unistd.h>

using namespace std;

int main(){
    int csock = socket(AF_INET,SOCK_STREAM,0);
    sockaddr_in caddr;
    caddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    caddr.sin_family = AF_INET;
    caddr.sin_port = htons(4002);

    connect(csock,(sockaddr*)&caddr,sizeof(caddr));
    char buff[100];
    while(1){
        string s;
        getline(cin,s);
        send(csock,s.c_str(),s.length(),0);
        bzero(buff,100);
        recv(csock,buff,100,0);
        if(buff[0] == 'e' && buff[1] == 'x' && buff[2] == 'i' && buff[3] == 't'){
            break;
        }
        cout<<buff<<endl;
    }
    close(csock);

}