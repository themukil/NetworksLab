#include<bits/stdc++.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<unistd.h>

using namespace std;

int main(){
    int ssock = socket(AF_INET,SOCK_STREAM,0);
    sockaddr_in saddr;
    saddr.sin_addr.s_addr = INADDR_ANY;
    saddr.sin_family = AF_INET;
    saddr.sin_port = htons(4002);

    bind(ssock,(sockaddr*)&saddr,sizeof(saddr));
    listen(ssock,5);

    sockaddr_in cli;
    socklen_t ln = sizeof(cli);

    int csock = accept(ssock,(sockaddr*)&cli,&ln);
    char buff[100];

    while(1){
        bzero(buff,100);
        recv(csock,buff,100,0);
        cout<<buff<<endl;
        string buf;
        getline(cin,buf);
        send(csock,buf.c_str(),buf.length(),0);
        if(buf == "exit"){
            break;
        }
    }
    close(csock);
    close(ssock);
}